# OreoBeat - Offline Music Player (Android 8.0+ API 26)

Lightweight, clean, and fully-featured offline music player engineered strictly for Android 8.0 Oreo (API 26) up to Android 14 (API 34).

## Architecture Highlights
- **Target SDK**: 34, **Min SDK**: 26 (Android 8.0 Oreo)
- **Background Playback**: `AndroidX Media3` (`MediaSessionService` + `ExoPlayer`) ensuring 100% compliance with Android 8 background execution limits.
- **Notification Channel**: Dedicated `"oreo_playback_channel"` with `IMPORTANCE_LOW` / high priority, MediaStyle controls (Play, Pause, Skip, Previous), and embedded album art.
- **Audio Focus**: Android 8.0+ `AudioFocusRequest.Builder` handling incoming phone calls (`AUDIOFOCUS_LOSS_TRANSIENT`), ducking, and `ACTION_AUDIO_BECOMING_NOISY` headphone disconnects.
- **Storage Scanner**: Clean `MediaStore.Audio.Media` queries for MP3, AAC, FLAC, WAV, and M4A.
- **Performance & Memory**: 
  - Coil image downscaling capped at 256x256 max to prevent OutOfMemory (OOM) on older 1GB/2GB RAM devices.
  - Strict AMOLED dark palette (`#121212`) reducing power draw on OLED screens.
- **Playlists & Queue**: Room Database with reactive Kotlin Coroutine Flows.
- **Hardware Equalizer**: 5-Band AudioFX (`60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz`) + Bass Boost.
