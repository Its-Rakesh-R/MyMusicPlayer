package com.oreobeat.musicplayer.ui

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.util.Log

/**
 * 5-Band Hardware Equalizer utilizing Android AudioFX framework.
 * Supports presets, individual band gains (-12dB to +12dB), and BassBoost.
 */
class EqualizerHelper(audioSessionId: Int) {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    init {
        try {
            if (audioSessionId != 0) {
                equalizer = Equalizer(0, audioSessionId).apply {
                    enabled = true
                }
                bassBoost = BassBoost(0, audioSessionId).apply {
                    enabled = true
                }
            }
        } catch (e: Exception) {
            Log.e("EqualizerHelper", "AudioFX init failed", e)
        }
    }

    fun getNumberOfBands(): Short = equalizer?.numberOfBands ?: 5

    fun getBandLevelRange(): ShortArray = equalizer?.bandLevelRange ?: shortArrayOf(-1200, 1200)

    fun setBandGain(band: Short, gainMilliBels: Short) {
        try {
            equalizer?.setBandLevel(band, gainMilliBels)
        } catch (e: Exception) {
            Log.e("EqualizerHelper", "Failed to set band gain", e)
        }
    }

    fun setBassBoost(strengthPercent: Short) {
        try {
            // BassBoost strength is 0 to 1000
            val strength = (strengthPercent.coerceIn(0, 100) * 10).toShort()
            bassBoost?.setStrength(strength)
        } catch (e: Exception) {
            Log.e("EqualizerHelper", "Failed to set bass boost", e)
        }
    }

    fun release() {
        equalizer?.release()
        bassBoost?.release()
        equalizer = null
        bassBoost = null
    }
}
