package com.oreobeat.musicplayer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes as Media3AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.oreobeat.musicplayer.R
import com.oreobeat.musicplayer.ui.MainActivity

/**
 * AndroidX MediaSessionService compliant with Android 8.0 (API 26) background execution limits.
 * Handles:
 * 1. Dedicated High-Priority "Playback" notification channel
 * 2. MediaStyle notification with controls and embedded album art
 * 3. AudioFocusRequest API 26 for call interruptions & transient ducking
 * 4. BecomingNoisy receiver for headphone disconnects
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var exoPlayer: ExoPlayer
    private lateinit var audioManager: AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var playbackDelayed = false
    private var resumeOnFocusGain = false

    companion object {
        const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "oreo_playback_channel"
        const val CHANNEL_NAME = "Music Playback"
        const val ACTION_PLAY = "com.oreobeat.musicplayer.ACTION_PLAY"
        const val ACTION_PAUSE = "com.oreobeat.musicplayer.ACTION_PAUSE"
        const val ACTION_NEXT = "com.oreobeat.musicplayer.ACTION_NEXT"
        const val ACTION_PREV = "com.oreobeat.musicplayer.ACTION_PREV"
        const val ACTION_STOP = "com.oreobeat.musicplayer.ACTION_STOP"
    }

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                // Pause playback automatically when headphones unplugged
                if (exoPlayer.isPlaying) {
                    exoPlayer.pause()
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // 1. Create dedicated Notification Channel for Android 8.0+
        createPlaybackNotificationChannel()

        // 2. Initialize ExoPlayer with AudioAttributes for Music
        val audioAttributes = Media3AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        exoPlayer = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, false) // We handle custom AudioFocus for Oreo
            .setHandleAudioBecomingNoisy(false)
            .build()

        // 3. Setup MediaSession
        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, exoPlayer)
            .setSessionActivity(sessionActivityPendingIntent)
            .build()

        // 4. Register becoming noisy receiver
        val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        registerReceiver(noisyReceiver, filter)

        // 5. Player listener for notification updates
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updateNotification()
                if (isPlaying) {
                    requestAudioFocusForOreo()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                updateNotification()
            }
        })
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createPlaybackNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW // Low ensures no sound on every track change
            ).apply {
                description = "Controls for background audio playback"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * API Level 26+ AudioFocusRequest handling
     */
    private fun requestAudioFocusForOreo(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val focusListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
                when (focusChange) {
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        if (playbackDelayed || resumeOnFocusGain) {
                            playbackDelayed = false
                            resumeOnFocusGain = false
                            exoPlayer.play()
                        }
                        exoPlayer.volume = 1.0f
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        // Duck volume during notifications
                        exoPlayer.volume = 0.2f
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        // Pause during incoming phone call
                        if (exoPlayer.isPlaying) {
                            resumeOnFocusGain = true
                            exoPlayer.pause()
                        }
                    }
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        // Permanent loss (another app took over)
                        resumeOnFocusGain = false
                        exoPlayer.pause()
                    }
                }
            }

            audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(focusListener)
                .build()

            val res = audioManager.requestAudioFocus(audioFocusRequest!!)
            return res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        return true
    }

    private fun updateNotification() {
        val currentItem = exoPlayer.currentMediaItem
        val title = currentItem?.mediaMetadata?.title?.toString() ?: "OreoBeat Player"
        val artist = currentItem?.mediaMetadata?.artist?.toString() ?: "Offline Music"
        val isPlaying = exoPlayer.isPlaying

        val notification = buildMediaNotification(title, artist, isPlaying, null)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildMediaNotification(
        title: String,
        artist: String,
        isPlaying: Boolean,
        albumArt: Bitmap?
    ): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        // Actions
        val prevPendingIntent = PendingIntent.getService(
            this, 1,
            Intent(this, PlaybackService::class.java).setAction(ACTION_PREV),
            PendingIntent.FLAG_IMMUTABLE
        )
        val playPausePendingIntent = PendingIntent.getService(
            this, 2,
            Intent(this, PlaybackService::class.java).setAction(if (isPlaying) ACTION_PAUSE else ACTION_PLAY),
            PendingIntent.FLAG_IMMUTABLE
        )
        val nextPendingIntent = PendingIntent.getService(
            this, 3,
            Intent(this, PlaybackService::class.java).setAction(ACTION_NEXT),
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(openIntent)
            .setOngoing(isPlaying)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(R.drawable.ic_skip_previous, "Previous", prevPendingIntent)
            .addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (isPlaying) "Pause" else "Play",
                playPausePendingIntent
            )
            .addAction(R.drawable.ic_skip_next, "Next", nextPendingIntent)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setShowActionsInCompactView(0, 1, 2)
            )

        if (albumArt != null) {
            builder.setLargeIcon(albumArt)
        }

        return builder.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> exoPlayer.play()
            ACTION_PAUSE -> exoPlayer.pause()
            ACTION_NEXT -> if (exoPlayer.hasNextMediaItem()) exoPlayer.seekToNextMediaItem()
            ACTION_PREV -> if (exoPlayer.hasPreviousMediaItem()) exoPlayer.seekToPreviousMediaItem()
            ACTION_STOP -> stopSelf()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(noisyReceiver)
        } catch (_: Exception) {}

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
            audioManager.abandonAudioFocusRequest(audioFocusRequest!)
        }

        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
